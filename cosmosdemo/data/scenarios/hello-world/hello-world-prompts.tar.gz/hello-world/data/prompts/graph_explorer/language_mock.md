## Example Queries (Natural Language)

- "Show me all servers in the topology"
- "What applications are hosted on SRV-ALPHA-01?"
- "Which database does APP-API-01 connect to?"
- "Find the blast radius if SRV-ALPHA-01 goes down"
- "List all applications using DB-PRIMARY-01"
- "Show me the full dependency chain from SRV-ALPHA-01 to its databases"
