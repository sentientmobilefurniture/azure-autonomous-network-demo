Graph Explorer agent for hello-world. Queries the infrastructure graph topology
via Gremlin to investigate server-application-database relationships, dependency
chains, blast radius, and root cause paths.
